# Movie Website with python generated html

## Install
1. Files:
    1. `movie.py` : Contains the movie class
    2. `enetertainment_center.py` : contains the movie database which will be shown on the page
    3. `fresh_tomatoes.py` : takes data and generates the html for the movie website. (provided by Udacity.)
2. Make sure all the above files are in the same folder. 
3. Run `enetertainment_center.py` in the pyhon shell. This will generate the `fresh_tomatoes.html` file, which is the movie website.
